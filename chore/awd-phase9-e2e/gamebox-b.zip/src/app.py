#!/usr/bin/env python3
"""Simple HTTP server for E2E testing - GameBox B."""
import http.server
import os

PORT = 80
FLAG_FILE = "/flag.txt"

class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/health":
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write(b"healthy")
        elif self.path == "/flag":
            try:
                with open(FLAG_FILE, "r") as f:
                    flag = f.read().strip()
                self.send_response(200)
                self.send_header("Content-Type", "text/plain")
                self.end_headers()
                self.wfile.write(flag.encode())
            except FileNotFoundError:
                self.send_response(404)
                self.end_headers()
        else:
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write(b"OK - GameBox B")

    def log_message(self, format, *args):
        pass

if __name__ == "__main__":
    with open(FLAG_FILE, "w") as f:
        f.write("FLAG_B_PLACEHOLDER")
    server = http.server.HTTPServer(("0.0.0.0", PORT), Handler)
    server.serve_forever()