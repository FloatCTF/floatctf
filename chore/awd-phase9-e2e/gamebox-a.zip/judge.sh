#!/bin/sh
# Judge script for e2e-web-a
# Check if the HTTP service is responding
wget -q -O - --timeout=5 http://$TARGET_IP:80/ 2>/dev/null | grep -q "OK" && exit 0 || exit 1