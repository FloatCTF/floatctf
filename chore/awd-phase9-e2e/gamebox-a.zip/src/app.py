#!/usr/bin/env python3
"""E2E GameBox A: HTTP server with health + flag endpoints.
Polls the AWD FlagServer (http://flagserver:8080/flag) for this instance's
per-round flag and writes it to /flag.txt (refresh per Attack round)."""
import http.server
import os
import threading
import urllib.request

PORT = 80
FLAG_FILE = "/flag.txt"
FLAGSERVER_URL = os.environ.get("FLAGSERVER_URL", "http://flagserver:8080/flag")
POLL_INTERVAL = int(os.environ.get("FLAG_POLL_INTERVAL_SECS", "20"))


def poll_flag():
    while True:
        try:
            with urllib.request.urlopen(FLAGSERVER_URL, timeout=8) as r:
                if r.status == 200:
                    flag = r.read().decode().strip()
                    if flag:
                        with open(FLAG_FILE, "w") as f:
                            f.write(flag + "\n")
        except Exception:
            pass  # Hardening / no flag yet — keep polling
        threading.Event().wait(POLL_INTERVAL)


class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/health":
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write(b"healthy")
        elif self.path == "/flag":
            try:
                with open(FLAG_FILE, "r") as f:
                    flag = f.read().strip()
                self.send_response(200)
                self.send_header("Content-Type", "text/plain")
                self.end_headers()
                self.wfile.write(flag.encode())
            except FileNotFoundError:
                self.send_response(404)
                self.end_headers()
        else:
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write(b"OK - GameBox A")

    def log_message(self, format, *args):
        pass  # Suppress logs


if __name__ == "__main__":
    threading.Thread(target=poll_flag, daemon=True).start()
    http.server.ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
