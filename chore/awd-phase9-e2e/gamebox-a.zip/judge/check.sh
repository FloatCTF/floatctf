#!/bin/sh
# Judge check for e2e-web-a — HTTP check via python3 urllib (JudgeServer base = python:slim, no wget)
python3 - "$TARGET_IP" <<'EOF'
import sys, urllib.request
url = "http://%s:80/" % sys.argv[1]
try:
    with urllib.request.urlopen(url, timeout=5) as r:
        body = r.read().decode("utf-8", "replace")
        sys.exit(0 if "OK" in body else 1)
except Exception:
    sys.exit(1)
EOF
