#!/bin/sh
# Judge script for e2e-web-b
# Check if the HTTP service is responding
wget -q -O - --timeout=5 http://$TARGET_IP:80/health 2>/dev/null | grep -q "healthy" && exit 0 || exit 1